export default function About() {
    return <h1>The about page</h1>;
}