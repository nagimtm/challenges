export default function Hulk() {
    return <h1>The Incredible Hulk</h1>;
  }